import { startBackendServer } from './dist/backend/index.js';
import { installTestFfmpeg } from './hls-test-installer.mjs';
process.env.ELFURA_EXPERIMENTAL_HLS_DOWNLOADS ??= '1';
startBackendServer();
void installTestFfmpeg();
