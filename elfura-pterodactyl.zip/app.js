import { startBackendServer } from './dist/backend/index.js';
startBackendServer();
