# Elfura Player

A small, fast, embeddable HLS/DASH player. JW-Player-grade restraint on the
outside; a fully dynamic input schema, real multi-language audio and a
completely customisable subtitle renderer underneath.

**Size:** initial chunk **22.9 KB gzip**. `hls.js` and `dash.js` are separate
chunks loaded on demand — an HLS title never downloads the DASH engine.

```
npm run dev        # vite dev server on 0.0.0.0:5173 (proxies /api -> backend)
npm run build      # typecheck (Part 1 + Part 2) + embed + lib + backend
npm start          # zero-dep Node production server on 0.0.0.0:${SERVER_PORT||PORT||8787}
npm test           # end-to-end security, TMDB, Source 1 & HLS/Range relay test suite
```

### Public landing site

The production server serves a complete public product site at `/`, with direct
entry points for `/demo`, `/docs`, and `/status`. It includes a live embed
builder, movie/series demo, copyable iframe/SDK/PostMessage examples, playback
telemetry, and health-driven infrastructure status.

All catalog artwork and title selections are dynamic. `GET /api/v1/catalog`
resolves trending movies, trending series, and popular Japanese animation from
TMDB, sanitizes the response, builds TMDB poster/backdrop URLs server-side, and
uses a bounded ten-minute RAM cache. The hero, poster filters, clickable poster
rail, and builder quick picks all consume that single response; there is no
hardcoded poster list or generated artwork fallback.

---

## 1. How the player takes input

**One declarative schema drives everything.** `src/core/params.ts` holds a
single table of parameters; parsing, validation, clamping, defaults and the
generated docs all derive from it. There is exactly one place that reads a
query string, so a new knob added there immediately works in all three
channels.

Three channels converge on one config, in this precedence order:

| # | Channel | When | Notes |
|---|---------|------|-------|
| 1 | `PARAM_SCHEMA` defaults | boot | |
| 2 | stored preferences | boot | audio language + subtitle style from `localStorage` |
| 3 | JS config object | boot | `Elfura.mount(el, {...})` / `Elfura.create(el, {...})` |
| 4 | **URL query params** | boot | win — the URL is the shareable, debuggable statement of intent |
| 5 | postMessage commands | runtime | mutate live state only |
| 6 | user interaction | runtime | clicks, keys, drag |

URL beats JS config on purpose: for an embeddable player the publisher's URL is
the more specific claim. Self-hosted code that wants the opposite passes
`ignoreUrlParams: true`. Bad input never throws — it is clamped or dropped and
reported in `issues` (visible with `?debug=1`).

Key parameters (full list: `Elfura.schemaDocs()`):

| Param | Type | Example | Purpose |
|---|---|---|---|
| `tmdb` | id | `94605` | TMDB ID used by the standard playback sources |
| `anilist` | id | `16498` | AniList ID used by bundled Anivexa; provide this alongside `tmdb` to load and prioritize anime sources |
| `mediaType` | enum | `tv` | `movie` or `tv` (also accepts `?type=movie\|tv` or `/embed/tv/:id/:s/:e`) |
| `season` / `episode` | int | `s=1&e=1` | 1-based season & episode for `tv` playback |
| `source` | id | `source-1` | pin a preferred uniform source adapter |
| `src` | url | `…/master.m3u8` | direct media URL when bypassing TMDB resolution |
| `type` | enum | `hls` | force a protocol instead of sniffing |
| `servers` | pairlist | `a:URL,b:URL` | ordered fallback servers; silent failover on fatal error |
| `t` | time | `1:30:00` | start position; accepts `90`, `1:30`, `01:02:03`, `1h2m3s` |
| `lang` | bcp47 | `hi` | preferred audio language |
| `audioTracks` | pairlist | `hi:URL,ta:URL` | **external dubs**, merged with manifest tracks |
| `sublang` | bcp47 | `en` | preferred subtitle language |
| `subsrc` | pairlist | `en:URL,hi:URL` | external subtitle files (VTT / SRT / ASS) |
| `substyle` | mini-lang | `size:120\|color:#ffd54a` | preset any subtitle style property |
| `color` | hex | `00b4ff` | accent; derived shades computed automatically |
| `skipStep` | int | `30` | ± seek seconds; buttons self-hide on short titles |
| `intro` / `outro` | range | `0:52` | coloured scrubber segments + skip pill |
| `autoplay` `muted` `loop` `speed` `volume` `quality` | — | | playback boot state |
| `controls` `keyboard` `back` `brand` `skin` | — | | chrome |
| `origin` | origin | `https://site.com` | locks the postMessage channel both ways |
| `pltoken` `nonce` | opaque | | forwarded verbatim on manifest requests, **never logged or posted** |

Time and colour coercion is forgiving by design (`ARGB` hex, `mm:ss`, bare
seconds all work) because embed builders emit inconsistent values in the wild.

## 2. Multi-language audio

Two kinds of track exist and conflating them is the usual cause of
"switching language stutters":

- **Native** (muxed in the manifest). HLS `EXT-X-MEDIA:TYPE=AUDIO`, DASH
  `AdaptationSet contentType="audio"`. Switching is an in-band operation — the
  engine swaps the audio SourceBuffer without touching the clock, so video
  never blinks.
- **External** (a separate file per language, `?audioTracks=hi:URL`). Common
  when dubs are produced apart from the video. There is no clean in-band switch,
  so the player keeps the video element running muted and drives a **second
  `<audio>` element locked to the video clock** (`core/audio.ts` →
  `ExternalAudioSync`), correcting drift continuously: hard-seek above 350 ms,
  gentle playback-rate nudge between 60–350 ms.

Both surface as one unified `AudioTrack[]`. Rules:

- **Matching:** `?lang=hi` matches `hi` exactly first, then primary subtag
  (`hi` satisfies `hi-IN`). Same rules for subtitles.
- **De-duplication:** an external track is dropped if the manifest already
  carries that language natively (native switches more cleanly).
- **Precedence:** explicit `?lang=` → stored preference → manifest `DEFAULT=YES`
  → first track.
- **Persistence:** the chosen language is remembered per browser and applied to
  future titles when `persistAudio=1` (default on). Turn off for a kiosk.
- **UI:** the audio button and the audio tab only appear when there is more
  than one track. A stream with one language shows nothing.

## 3. Subtitle customisation

Native `<track>::cue` cannot express per-property opacity, free positioning or
font control, and differs per browser — so the player parses **VTT, SRT and
SSA/ASS itself** (`subs/parser.ts`) and paints a DOM overlay (`subs/renderer.ts`).

Everything below is a key in `SubtitleStyle`, settable via the style panel, via
`?substyle=k:v|k:v`, or via the `setSubtitleStyle` postMessage command:

| Group | Controls |
|---|---|
| Colour | text colour, background colour |
| **Transparency** | **text transparency and background transparency, independently** (0–100%). The UI speaks "transparency"; the model stores opacity, so "transparent box, solid text" is one slider each |
| Font | family (8 stacks), size (40–220%), weight (Regular→Extra bold), italic, uppercase, letter spacing |
| Legibility | outline on/off + colour + width; drop shadow on/off + blur |
| Box | padding, corner radius, max width |
| **Position** | top/bottom edge, distance from edge (0–45%), left/centre/right align, horizontal nudge (−40…40%) — **plus drag-the-captions-directly-on-the-video**, which writes back to the same sliders so both stay in sync |

Font size is a percentage of a **720p baseline scaled to the actual player
height**, so 100% reads identically in a 480 px embed and in fullscreen.

Persistence: the user's style is saved to `localStorage` and reused across
titles and embeds on the origin (`persistSubs=1`, default on); a publisher's
`?substyle=` always overrides the stored value for that embed.

The style panel edits a **live preview renderer** (a real `SubtitleRenderer`
over a synthetic surface), so every slider is verifiable before it touches the
video — and the same changes apply to real cues immediately.

## 4. Chrome behaviour (per the reference design)

- Thin full-width scrubber riding on a solid control bar; ±step, volume, time
  on the left; audio / CC / settings / PiP / fullscreen on the right.
- Settings is an **icon-tabbed overlay**: Quality · Subtitles · Speed · Audio.
  Tabs exist only when the stream offers something — no audio tab with one
  track, no CC tab with none, no gear at all when there is nothing to set.
- Quality HUD top-right shows `Quality: Auto` plus a pill with the **effective**
  resolution the ABR is actually serving (`LEVEL_SWITCHED` / `QUALITY_CHANGE_RENDERED`).
- Centre state flash on play/pause/seek; buffering spinner; auto-hide after 2.6 s.
- Intro/outro render as coloured segments inside the scrubber plus a skip pill.
  Segment metadata is resolved independently of stream racing, and the ranges
  refresh on initial UI creation and `loadedmetadata`. Intro/outro clicks seek
  past the range; an outro opens the next episode instead when one is available.
- When OpenSubtitles returns usable tracks, every stream exposes that same
  deduplicated one-track-per-language catalogue. Native subtitles are retained
  only as the fallback when OpenSubtitles has no usable result.

### Nothing is hardcoded
Quality rows come from the manifest; tabs, buttons and segments derive from
stream capability and config; time format adapts to duration; the accent and
every derived shade come from one CSS custom property.

### It stays fast
One `requestAnimationFrame` loop drives time/scrubber/buffer and writes a DOM
property only when the value changed; the panel body is built once per open and
tab switches swap only the body; no `innerHTML` in the hot path; engines are
code-split and fetched only when needed.

## 5. Embedding & the postMessage protocol

```html
<iframe src="https://play.example.com/embed.html?src=…&lang=hi&color=00b4ff"
        allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>
```

Versioned envelope, origin-locked in both directions:

```js
// -> iframe   { __elfura:1, v:1, kind:'cmd',   name:'setSubtitleStyle', data:{ value:{ fontSizePct:130 } }, reqId }
// <- iframe   { __elfura:1, v:1, kind:'ack',   reqId, ok:true }
// <- iframe   { __elfura:1, v:1, kind:'event', name:'audioChange', data:{ lang:'hi', label:'Hindi' } }
```

Commands are acked, so a host can `await` them: `createHostClient(iframe).send('seek', { value: 90 })`.
`pltoken` / `nonce` are redacted from every outbound message and log.

## 6. Uniform Backend & Pterodactyl Deployment (`backend/`)

Elfura maintains a strict separation between **Part 1 (`src/`)** and **Part 2 (`backend/`)** (see [`RULES.md`](./RULES.md)):

- **Clean TMDB Embed URLs:**
  - Movie: `/embed/movie/:tmdbId` or `/embed?tmdb=:tmdbId&type=movie`
  - TV Episode: `/embed/tv/:tmdbId/:season/:episode` or `/embed?tmdb=:tmdbId&type=tv&s=1&e=1`
  - Anime episode with AniList-aware providers prioritized: `/embed?tmdb=:tmdbId&anilist=:anilistId&type=tv&s=1&e=1`
- **Single Uniform Endpoint (`GET/POST /api/v1/playback`):** Resolves TMDB metadata (from your self-hosted `TMDB_API_BASE`) + modular `SourceAdapter` streams into one uniform schema with zero upstream provider names or raw CDN URLs exposed, wrapped in an **AES-256-GCM Sealed Playback Envelope** (`X-Elfura-Envelope: 1`) so DevTools Network Preview and copied cURL commands only see ciphertext.
- **Smart Hybrid Stream Relay (`GET /api/v1/stream?t=<ticket>`, `RELAY_MODE=hybrid`):** Encrypts upstream URLs and required `Referer`/`Origin` headers inside AES-256-GCM tickets, always relays manifests/subtitles/keys and header-locked or source-identifying streams in memory with zero disk writes, and offloads verified anonymous CORS-safe HTTPS video segments directly to edge CDNs (keeping Cloudflare Proxy & 2 GB RAM Pterodactyl containers safe at scale, with automatic `&p=1` backend-tunnel failover if a viewer's ISP blocks an external CDN).
- **Pterodactyl Ready (`elfura-pterodactyl.zip`):** Upload `elfura-pterodactyl.zip` to `/home/container` in Pterodactyl's **Files** tab and click **Unarchive** (flat-root archive — extracts directly into `/home/container` with pre-built `dist/` and zero heavy `node_modules`). Edit `.env` (or Startup variables) with `ELFURA_SECRET`, `TMDB_API_BASE`, and `ALLOWED_ORIGINS`, then click **Start**.

  **Startup file: set it to `index.js`.** The zip ships `index.js`, `server.js`, `app.js`, `main.js`, `bot.js`, `start.js` and `src/index.js` — all identical plain JavaScript, so whichever name your egg expects exists. Do **not** point the startup command at a TypeScript toolchain.

  If your egg hard-codes `ts-node --esm index.ts`, change it to `node index.js`. TypeScript files are deliberately not shipped: this project's runtime output is already compiled into `dist/`, and a `.ts` entrypoint makes the host install a compiler it never needs. Some `ts-node` 10.x builds also crash on Node 22 with `Cannot find module './--max-old-space-size=384'` inside `imaginaryUncacheableRequireResolveScript`, which reads as a boot loop in the panel console.

  If you cannot change the startup command, `node index.js` still works when launched through `ts-node`/`tsx` — the entrypoint detects a TypeScript runner, ignores its injected flags, and serves the compiled build. It just needs the runner installed.

## 7. Layout

```
RULES.md                  strict Part 1 / Part 2 architecture & zero-disk rules
src/core/params.ts        input schema (single source of truth)
src/core/config.ts        precedence + path/SSR boot + provenance + redaction
src/core/events.ts        event bus + origin-locked postMessage bridge
src/core/audio.ts         native/external tracks, language matching, sync engine
src/core/player.ts        engine adapters (lazy), uniform API client, source failover
src/subs/parser.ts        VTT / SRT / ASS -> Cue[]
src/subs/renderer.ts      DOM overlay renderer, drag-to-position
src/subs/style.ts         SubtitleStyle model, clamping, persistence
src/ui/controls.ts        chrome, Sources/Quality/CC/Speed/Audio panel, rAF loop
src/ui/styles.css         one accent property, derived shades
embed.html                iframe surface
backend/src/index.ts      zero-dep HTTP server + SSR token bootstrap
backend/src/config.ts     env config (SERVER_PORT, ELFURA_SECRET, TMDB_API_BASE)
backend/src/security.ts   HMAC pltoken, AES-256-GCM stream tickets, SSRF & rate limit
backend/src/tmdb.ts       self-hosted TMDB metadata client
backend/src/relay.ts      zero-disk HLS/DASH manifest rewriter & Range stream proxy
backend/src/sources/      isolated SourceAdapter registry + Source 1–20 adapters (16 bundled Anivexa anime aggregator — pass both `tmdb` and `anilist`; 17 AniVortex catalogue, opt-in and needs installation credentials from `scripts/anivortex-register.mjs`; 18 SubDubAnime Hindi/English sub+dub anime; 19 DesiDubAnime Hindi/Tamil/Telugu dubs; 20 Vidora TMDB-keyed HLS + subtitles)
```

## Roxy operator dashboard

Open `/roxy` on the backend origin and sign in with the existing `ELFURA_SECRET` from `.env`. Configure a strong, non-placeholder secret and use HTTPS. The secret is not copied into the deployment ZIP. The dashboard shows actual embed playback starts, approximate active viewers (last heartbeat within 60 seconds), reported terminal playback failures, embedding origins, and on-demand HTTP checks of source websites. Counts start from installation, not historical data; SDK and direct API playback are not included. Titles fall back to TMDB IDs when metadata is unavailable. An HTTP response does not guarantee playback.

Analytics are kept for 72 hours and pruned automatically. The clear button deletes analytics immediately but deliberately preserves site bans. Data and bans are persisted in `data/roxy.json` (or in the directory specified by `ROXY_DATA_DIR`), outside the deployment ZIP; keep this directory writable and persistent across deployments. No client IPs, full referrer URLs, stream URLs or playback tokens are stored. Storage errors are shown on the dashboard.

### Recommended: Cloudflare Worker relay (no `.env` editing)

A proxy list costs money per request and gets throttled — discovery alone fires
dozens of requests per page load. A Cloudflare Worker is the better egress: one URL,
one hop, no credential rotation, and the free plan's 100,000 requests/day is far above
what discovery uses.

1. Deploy `cloudflare-worker/worker.js` — see [cloudflare-worker/README.md](./cloudflare-worker/README.md)
   for the browser-only steps and the `TOKEN` secret.
2. In `/roxy`, open **Egress relay**, paste the Worker URL and the token, then **Save**.
3. Press **Test relay**. It answers with Cloudflare's exit address, which should not be
   this server's address.

The boot log then says `discovery requests are relayed through <host>`. If the Worker
ever fails three times in a row it is skipped for a minute and requests go direct, so a
broken relay degrades to the previous behaviour instead of stalling every source. Media
playback never goes through the relay.

The URL and token can also be set as `ELFURA_UPSTREAM_RELAY` / `ELFURA_RELAY_TOKEN`, in
which case the environment or `.env` wins and the panel shows the value as locked.

### Proxy list (no `.env` editing)

If source discovery fails because provider websites refuse this server's IP, upload a proxy list instead of editing files. Open `/roxy`, sign in, and use the **Proxy pool** panel: pick your provider's `.txt` file and press **Upload proxy list**, or paste the lines into the box and press **Save pasted list**. One proxy per line, in any of these shapes:

```
45.38.107.97:6014:username:password     ← Webshare's export format
http://username:password@host:port
username:password@host:port
host:port                                ← open proxy, no login
```

Press **Test all** to check the list. Each reachable proxy shows the exit address the internet sees, and the panel reports how many answered. If none answer, the panel also probes the same endpoint *without* a proxy: when that works, the proxies are the problem; when it also fails, the hosting network is. Working proxies are used for source discovery in rotation, three per request, with automatic failover and a direct fallback, so one dead proxy never removes a source. A proxy that fails three times rests for a minute and is marked `SKIPPED`. Passwords are written to `data/proxies.json` (mode 0600) and are never returned to the browser or written to the log. The uploaded list takes precedence over the single `ELFURA_UPSTREAM_PROXY` `.env` value. Media playback traffic is not routed through the list.

Website attribution and banning use the browser's `Referer` origin on embed requests. This is best-effort, not authentication: referrers can be absent or spoofed, direct API users are not covered, and already-playing streams are not immediately disconnected. Missing referrers appear as unknown. Use proper authenticated, origin-bound integration credentials and network policy if strong access control is required.

